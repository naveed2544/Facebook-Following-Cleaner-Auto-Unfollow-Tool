# FB Following Cleaner v1.2.0

## What changed
- Start All now keeps running until the list is fully scanned twice or you press Stop.
- Automatically scrolls to load more following items.
- Supports both visible Following/Friends buttons and three-dots/Actions menus.
- Retries a card instead of stopping after one missing action.
- Performs a final verification sweep from the top before reporting completion.
- Stops automatically only when the list is finished, the user presses Stop, the page changes, or Facebook displays an action restriction/security check.

## Install
1. Extract this ZIP.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Remove or disable the older version.
5. Click **Load unpacked** and select the extracted folder containing `manifest.json`.
6. Reload the Facebook tab once.
7. Open your Following list, open the extension, and press **Start All**.

Facebook changes its interface frequently. Keep the Following tab open while the cleaner runs.
