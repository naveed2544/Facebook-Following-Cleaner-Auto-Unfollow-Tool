/**
 * background.js (Manifest V3 service worker)
 * ---------------------------------------------------------------------------
 * Lightweight coordinator. Its jobs:
 *   1. Track which tabs are Facebook tabs and update the toolbar badge/icon
 *      state accordingly (visual "is this Facebook?" indicator).
 *   2. Relay a couple of simple messages between the content script and
 *      popup when needed.
 *   3. React to tab updates/activation so the badge stays correct as the
 *      user switches tabs or navigates.
 *
 * Service workers in MV3 are event-driven and can be unloaded when idle —
 * so we avoid relying on any in-memory state that must survive across
 * restarts. Everything here is recomputed cheaply from the tab URL.
 */

const FACEBOOK_HOST_PATTERN = /(^|\.)facebook\.com$/i;

/** Returns true if the given URL string is a facebook.com page. */
function isFacebookUrl(urlString) {
  try {
    const url = new URL(urlString);
    return FACEBOOK_HOST_PATTERN.test(url.hostname);
  } catch {
    return false;
  }
}

/** Update the action badge for a given tab based on whether it's Facebook. */
async function refreshBadgeForTab(tabId, url) {
  const onFacebook = isFacebookUrl(url || "");

  try {
    if (onFacebook) {
      await chrome.action.setBadgeText({ tabId, text: "FB" });
      await chrome.action.setBadgeBackgroundColor({
        tabId,
        color: "#2563EB",
      });
      await chrome.action.setTitle({
        tabId,
        title: "FB Following Cleaner — Facebook detected",
      });
    } else {
      await chrome.action.setBadgeText({ tabId, text: "" });
      await chrome.action.setTitle({
        tabId,
        title: "FB Following Cleaner — open a Facebook tab to begin",
      });
    }
  } catch (err) {
    // Tab may have closed mid-update; safe to ignore.
    console.debug("[FB Following Cleaner] badge update skipped:", err);
  }
}

// Fires when a tab finishes loading or its URL changes (SPA navigations on
// Facebook also fire "loading"/"complete" status updates we can catch here).
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" || changeInfo.url) {
    refreshBadgeForTab(tabId, tab.url);
  }
});

// Fires when the user switches to a different tab.
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    refreshBadgeForTab(tabId, tab.url);
  } catch (err) {
    console.debug("[FB Following Cleaner] onActivated skipped:", err);
  }
});

// Content script pings us as soon as it loads on a Facebook page — handy
// for setting the badge immediately without waiting on tabs.onUpdated.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "FACEBOOK_TAB_DETECTED" && sender.tab?.id != null) {
    refreshBadgeForTab(sender.tab.id, sender.tab.url);
    sendResponse({ ok: true });
  }
  // Not returning true here (no async work left) — response already sent.
  return false;
});

// Set a sane default badge state on install/update.
chrome.runtime.onInstalled.addListener(async () => {
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (tab.id != null) refreshBadgeForTab(tab.id, tab.url);
    }
  } catch (err) {
    console.debug("[FB Following Cleaner] onInstalled badge sweep skipped:", err);
  }
});
