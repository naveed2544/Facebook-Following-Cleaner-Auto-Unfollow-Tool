/**
 * FB Following Cleaner + Profile Insights
 * Runs only on facebook.com and performs local, visible-page actions.
 */
(() => {
  "use strict";

  // Versioned guard. Reload Facebook after updating so older listeners are gone.
  if (globalThis.__FB_FOLLOWING_CLEANER_V120__) return;
  globalThis.__FB_FOLLOWING_CLEANER_V120__ = true;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function normalizeText(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function getTextVariants(el) {
    if (!el) return [];
    return [...new Set([
      el.getAttribute?.("aria-label"),
      el.getAttribute?.("title"),
      el.innerText,
      el.textContent,
    ].map(normalizeText).filter(Boolean))];
  }

  function getElementText(el) {
    return getTextVariants(el).join(" ");
  }

  function isVisible(el, margin = 260) {
    if (!(el instanceof Element) || !el.isConnected) return false;
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) {
      return false;
    }
    const rect = el.getBoundingClientRect();
    return rect.width > 2 && rect.height > 2 && rect.bottom >= -margin && rect.top <= innerHeight + margin;
  }

  function getMeta(propertyOrName) {
    const el =
      document.querySelector(`meta[property="${propertyOrName}"]`) ||
      document.querySelector(`meta[name="${propertyOrName}"]`);
    return el ? el.getAttribute("content")?.trim() || null : null;
  }

  function getVisibleText() {
    const text = document.body ? document.body.innerText : "";
    return text.replace(/\s+/g, " ").trim().slice(0, 200000);
  }

  function parseShorthandNumber(raw) {
    if (!raw) return null;
    const cleaned = raw.replace(/,/g, "").trim();
    const match = cleaned.match(/^([\d.]+)\s*([KkMmBb]?)$/);
    if (!match) return null;
    let value = parseFloat(match[1]);
    if (Number.isNaN(value)) return null;
    const suffix = match[2].toUpperCase();
    if (suffix === "K") value *= 1_000;
    if (suffix === "M") value *= 1_000_000;
    if (suffix === "B") value *= 1_000_000_000;
    return Math.round(value);
  }

  function extractStat(text, labelPattern) {
    const regex = new RegExp(`([\\d][\\d,.]*\\s?[KkMmBb]?)\\s*(?:${labelPattern})`, "i");
    const match = text.match(regex);
    if (!match) return null;
    const display = match[1].trim();
    return { display, value: parseShorthandNumber(display) };
  }

  function detectPageKind(url) {
    const ogType = getMeta("og:type");
    const path = url.pathname.replace(/\/+$/, "");
    const nonProfilePaths = ["", "/", "/home.php", "/watch", "/marketplace", "/groups", "/gaming", "/notifications", "/messages", "/friends", "/events"];
    if (nonProfilePaths.includes(path) || path.startsWith("/watch")) return "other";
    if (ogType && ogType.includes("profile")) return "profile";
    if (path.startsWith("/profile.php")) return "profile";

    const segments = path.split("/").filter(Boolean);
    const reserved = new Set(["pages", "groups", "watch", "marketplace", "gaming", "events", "photo", "photo.php", "reel", "story.php", "hashtag", "share", "login", "help", "settings", "feed"]);
    const profileSubpages = new Set(["about", "friends", "followers", "following", "photos", "videos", "reels", "posts"]);
    if (segments.length === 1 && !reserved.has(segments[0])) return "profile";
    if (segments.length >= 2 && !reserved.has(segments[0]) && profileSubpages.has(segments[1])) return "profile";
    if (segments[0] === "people" && segments.length >= 3) return "profile";
    return "other";
  }

  function getUsername(url) {
    const path = url.pathname.replace(/\/+$/, "");
    if (path.startsWith("/profile.php")) {
      const id = url.searchParams.get("id");
      return id ? `id:${id}` : null;
    }
    const segments = path.split("/").filter(Boolean);
    return segments.length ? segments[0] : null;
  }

  function scrapeProfileData() {
    const url = new URL(location.href);
    const visibleText = getVisibleText();
    const desc = getMeta("og:description");
    return {
      isFacebook: true,
      pageKind: detectPageKind(url),
      url: url.href,
      username: getUsername(url),
      name: getMeta("og:title") || document.title?.trim() || null,
      photoUrl: getMeta("og:image"),
      bio: desc ? (desc.length > 220 ? `${desc.slice(0, 217)}...` : desc) : null,
      stats: {
        followers: extractStat(visibleText, "followers") || { display: null, value: null },
        following: extractStat(visibleText, "following") || { display: null, value: null },
        friends: extractStat(visibleText, "friends(?!\\s*(?:list|in\\s*common))") || { display: null, value: null },
      },
      scrapedAt: new Date().toISOString(),
    };
  }

  // ---------------------------------------------------------------------------
  // Following cleaner
  // ---------------------------------------------------------------------------

  const FOLLOWING_PATH_RE = /(?:\/following(?:\/|$)|[?&](?:sk|section)=following(?:&|$)|\/friends(?:\/|\?|$).*\bfollowing\b)/i;
  const processedKeys = new Set();
  const failedAttempts = new Map();
  const finalSkippedKeys = new Set();
  let cleanerLoopPromise = null;
  let lastScrape = scrapeProfileData();

  const cleaner = {
    running: false,
    paused: false,
    stopRequested: false,
    removed: 0,
    skipped: 0,
    errors: 0,
    visibleCandidates: 0,
    lastAction: "Ready. Open your Following list.",
    currentName: null,
    delayMin: 5000,
    delayMax: 8000,
    startedAt: null,
    finishedAt: null,
    sweep: 1,
    emptyBottomPasses: 0,
  };

  function isFollowingPage() {
    if (FOLLOWING_PATH_RE.test(location.href)) return true;
    const headingText = Array.from(document.querySelectorAll("h1,h2,[role='heading']"))
      .filter((el) => isVisible(el, 800))
      .flatMap(getTextVariants)
      .join(" ");
    return /following|people and pages you follow|people you follow|unfollow people|فالو|متابعة|siguiendo|abonnements|gefolgt|seguindo/i.test(headingText);
  }

  function looksLikeProfileHref(href) {
    try {
      const url = new URL(href, location.href);
      if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return false;
      const path = url.pathname.replace(/\/+$/, "");
      if (!path || path === "/") return false;
      const blocked = /^\/(friends|following|followers|groups|pages|watch|marketplace|settings|help|notifications|messages|events|feed|privacy|terms|policies|ads)(\/|$)/i;
      return !blocked.test(path);
    } catch {
      return false;
    }
  }

  function cleanProfileUrl(href) {
    try {
      const url = new URL(href, location.href);
      const allowed = new URLSearchParams();
      if (url.pathname === "/profile.php" && url.searchParams.get("id")) {
        allowed.set("id", url.searchParams.get("id"));
      }
      return `${url.origin}${url.pathname.replace(/\/+$/, "")}${allowed.toString() ? `?${allowed}` : ""}`;
    } catch {
      return String(href || "").split("?")[0].replace(/\/$/, "");
    }
  }

  function findAccountContext(control) {
    let node = control;
    let fallback = null;

    for (let depth = 0; node && depth < 11; depth += 1, node = node.parentElement) {
      if (node.matches?.("header,[role='navigation'],[role='dialog'],[role='menu']")) break;
      const links = Array.from(node.querySelectorAll?.("a[href]") || []).filter((a) => looksLikeProfileHref(a.href));
      if (!links.length) continue;

      const namedLinks = links.filter((a) => {
        const name = getTextVariants(a).find((text) => text.length >= 2 && text.length <= 120);
        return Boolean(name);
      });
      const profileLink = namedLinks[0] || links[0];
      const name = getTextVariants(profileLink).find((text) => text.length >= 2 && text.length <= 120) || "Facebook account";
      const context = {
        key: cleanProfileUrl(profileLink.href).toLowerCase(),
        name,
        card: node,
        profileLink,
      };

      // Prefer a compact card containing only a few profile links.
      if (links.length <= 4) return context;
      fallback ||= context;
    }

    if (fallback) return fallback;
    const label = getTextVariants(control)[0] || "Following account";
    return {
      key: `${label.toLowerCase()}|${Math.round(control.getBoundingClientRect().top + scrollY)}`,
      name: label,
      card: control.parentElement,
      profileLink: null,
    };
  }

  function lower(value) {
    return normalizeText(value).toLocaleLowerCase();
  }

  function isDirectTriggerText(text) {
    const t = lower(text);
    if (!t || t.length > 180) return false;
    return (
      /^(following|friends|liked|followed|follows)(?:\b|\s|$)/i.test(t) ||
      /^(فالو کر رہے ہیں|فالوئنگ|دوست|متابعة|الأصدقاء|siguiendo|amis|abonné|abonnée|gefolgt|seguindo)(?:\b|\s|$)/i.test(t)
    );
  }

  function isMenuTriggerText(text) {
    const t = lower(text);
    if (!t || t.length > 180) return false;
    if (/navigation|notification|search|messenger|account menu|your profile/i.test(t)) return false;
    return (
      /^(actions?(?: for)?|more(?: options)?|see options|options|menu|manage)(?:\b|\s|$)/i.test(t) ||
      /^(مزید|اختیارات|ایکشنز|المزيد|خيارات|acciones|más|plus|optionen|mais)(?:\b|\s|$)/i.test(t)
    );
  }

  function isUnfollowText(text) {
    const t = lower(text);
    if (!t || t.length > 220) return false;
    if (/unfriend|block|remove friend|report/i.test(t)) return false;
    return (
      /^unfollow(?:\b|\s|$)/i.test(t) ||
      /\bstop following\b/i.test(t) ||
      /فالو کرنا بند|ان\s*فالو|فالو ختم|إلغاء المتابعة|عدم المتابعة|ne plus suivre|no seguir|dejar de seguir|entfolgen|deixar de seguir/i.test(t)
    );
  }

  function isConfirmText(text) {
    const t = lower(text);
    if (!t || t.length > 120) return false;
    if (/cancel|back|not now|later|منسوخ|إلغاء/i.test(t)) return false;
    return /^(update|confirm|save|done|yes|apply|تصدیق|محفوظ|ہو گیا|تحديث|تأكيد|حفظ|enregistrer|confirmer|confirmar|guardar|speichern|bestätigen|salvar)(?:\b|\s|$)/i.test(t);
  }

  function isFollowStateText(text) {
    const t = lower(text);
    if (!t) return false;
    return /^(follow|like|add friend)(?:\b|\s|$)/i.test(t) && !/^following\b/i.test(t);
  }

  function elementMatches(el, predicate) {
    return getTextVariants(el).some(predicate);
  }

  function getAttemptCount(key) {
    return failedAttempts.get(key) || 0;
  }

  function findCandidateButtons() {
    if (!isFollowingPage()) return [];
    const all = Array.from(document.querySelectorAll("button,[role='button']"));
    const found = [];
    const seen = new Set();

    for (const el of all) {
      if (!isVisible(el)) continue;
      if (el.closest("[role='dialog'],[role='menu'],header,[role='navigation']")) continue;

      const direct = elementMatches(el, isDirectTriggerText);
      const menu = !direct && elementMatches(el, isMenuTriggerText);
      if (!direct && !menu) continue;

      const context = findAccountContext(el);
      if (!context || processedKeys.has(context.key) || seen.has(context.key)) continue;
      if (!context.card?.querySelector?.("a[href]")) continue;
      if (getAttemptCount(context.key) >= 3) continue;

      // A generic menu button is accepted only inside a compact account card.
      if (menu) {
        const cardRect = context.card.getBoundingClientRect?.();
        const profileLinks = Array.from(context.card.querySelectorAll?.("a[href]") || []).filter((a) => looksLikeProfileHref(a.href));
        if (!cardRect || cardRect.height > Math.max(700, innerHeight * 1.3) || profileLinks.length > 5) continue;
      }

      seen.add(context.key);
      found.push({ control: el, kind: direct ? "direct" : "menu", ...context });
    }

    return found.sort((a, b) => a.control.getBoundingClientRect().top - b.control.getBoundingClientRect().top);
  }

  function refreshVisibleCandidateCount() {
    cleaner.visibleCandidates = findCandidateButtons().length;
    return cleaner.visibleCandidates;
  }

  function randomDelay() {
    const min = Math.max(2500, Number(cleaner.delayMin) || 5000);
    const max = Math.max(min, Number(cleaner.delayMax) || 8000);
    return Math.floor(min + Math.random() * (max - min + 1));
  }

  function highlight(el) {
    if (!(el instanceof HTMLElement)) return;
    const previous = el.style.outline;
    const previousOffset = el.style.outlineOffset;
    el.style.outline = "3px solid #f59e0b";
    el.style.outlineOffset = "3px";
    setTimeout(() => {
      try {
        el.style.outline = previous;
        el.style.outlineOffset = previousOffset;
      } catch {
        // The element may be removed by Facebook after unfollowing.
      }
    }, 1800);
  }

  function activeActionRoots() {
    const roots = Array.from(document.querySelectorAll("[role='dialog'],[role='menu'],[role='listbox']")).filter((el) => isVisible(el, 50));
    return roots.length ? roots : [document];
  }

  function findVisibleAction(predicate, roots = null) {
    const searchRoots = roots?.length ? roots : activeActionRoots();
    for (const root of searchRoots) {
      const elements = Array.from(root.querySelectorAll?.("button,[role='button'],[role='menuitem'],[role='menuitemradio'],[role='option'],label") || []);
      for (const el of elements) {
        if (!isVisible(el, 100)) continue;
        if (elementMatches(el, predicate)) return el;
      }
    }
    return null;
  }

  async function waitForAction(predicate, timeoutMs = 3200, roots = null) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const el = findVisibleAction(predicate, roots);
      if (el) return el;
      await sleep(140);
    }
    return null;
  }

  function closeTransientUi() {
    try {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
      document.dispatchEvent(new KeyboardEvent("keyup", { key: "Escape", code: "Escape", bubbles: true }));
    } catch {
      // Ignore synthetic-event failures.
    }
  }

  function pageIsBlocked() {
    const text = getVisibleText().slice(-25000);
    return /you.?re temporarily blocked|we limit how often|try again later|action blocked|suspicious activity|security check|confirm your identity|temporarily restricted/i.test(text);
  }

  function atDocumentBottom() {
    const doc = document.scrollingElement || document.documentElement;
    return doc.scrollTop + innerHeight >= doc.scrollHeight - 140;
  }

  async function waitForPageMovement(previousHeight, previousTop, timeoutMs = 2400) {
    const doc = document.scrollingElement || document.documentElement;
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (doc.scrollHeight > previousHeight + 20 || Math.abs(doc.scrollTop - previousTop) > 120 || findCandidateButtons().length > 0) {
        return true;
      }
      await sleep(180);
    }
    return false;
  }

  async function loadMoreCandidates() {
    const doc = document.scrollingElement || document.documentElement;
    const beforeHeight = doc.scrollHeight;
    const beforeTop = doc.scrollTop;
    const targetTop = Math.min(doc.scrollHeight, beforeTop + Math.max(700, innerHeight * 0.86));
    window.scrollTo({ top: targetTop, behavior: "smooth" });
    await waitForPageMovement(beforeHeight, beforeTop, 2600);
    await sleep(500);
    refreshVisibleCandidateCount();
    return {
      moved: Math.abs(doc.scrollTop - beforeTop) > 80,
      grew: doc.scrollHeight > beforeHeight + 20,
      atBottom: atDocumentBottom(),
      height: doc.scrollHeight,
      top: doc.scrollTop,
    };
  }

  async function waitForDirectToggle(target, timeoutMs = 2200) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (!target.control.isConnected || !target.card?.isConnected) return true;
      if (elementMatches(target.control, isFollowStateText)) return true;

      const currentControls = Array.from(target.card.querySelectorAll?.("button,[role='button']") || []).filter((el) => isVisible(el, 150));
      if (currentControls.some((el) => elementMatches(el, isFollowStateText))) return true;
      await sleep(140);
    }
    return false;
  }

  async function clickControl(el) {
    if (!(el instanceof Element) || !el.isConnected) return false;
    try {
      el.focus?.({ preventScroll: true });
      el.click();
      return true;
    } catch {
      try {
        el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
        return true;
      } catch {
        return false;
      }
    }
  }

  function recordAttemptFailure(target, message) {
    const attempts = getAttemptCount(target.key) + 1;
    failedAttempts.set(target.key, attempts);
    cleaner.currentName = null;
    cleaner.lastAction = `${message} (${attempts}/3)`;
    closeTransientUi();
    refreshVisibleCandidateCount();
    return { ok: false, code: "ACTION_NOT_FOUND", error: cleaner.lastAction, key: target.key };
  }

  async function unfollowOne() {
    if (!isFollowingPage()) {
      return { ok: false, code: "WRONG_PAGE", error: "Open your Facebook Following list first." };
    }
    if (pageIsBlocked()) {
      return { ok: false, code: "FACEBOOK_BLOCK", error: "Facebook has paused or blocked actions on this account. Try again later." };
    }

    let candidates = findCandidateButtons();
    if (!candidates.length) {
      cleaner.visibleCandidates = 0;
      return { ok: false, code: "NO_VISIBLE", error: "No removable account is visible yet." };
    }

    const target = candidates[0];
    cleaner.currentName = target.name;
    cleaner.lastAction = `Opening ${target.name}…`;
    target.control.scrollIntoView({ behavior: "smooth", block: "center" });
    await sleep(450);
    highlight(target.control);

    if (!(await clickControl(target.control))) {
      return recordAttemptFailure(target, `Could not click ${target.name}`);
    }

    // Some layouts toggle Following -> Follow immediately without a menu.
    if (target.kind === "direct") {
      const directSuccess = await waitForDirectToggle(target, 1100);
      if (directSuccess) {
        processedKeys.add(target.key);
        failedAttempts.delete(target.key);
        cleaner.removed += 1;
        cleaner.currentName = null;
        cleaner.lastAction = `Removed: ${target.name}`;
        await sleep(350);
        refreshVisibleCandidateCount();
        return { ok: true, name: target.name, mode: "direct" };
      }
    }

    const unfollowAction = await waitForAction(isUnfollowText, 3800);
    if (!unfollowAction) {
      // A delayed direct toggle may have completed while waiting for a menu.
      if (await waitForDirectToggle(target, 500)) {
        processedKeys.add(target.key);
        failedAttempts.delete(target.key);
        cleaner.removed += 1;
        cleaner.currentName = null;
        cleaner.lastAction = `Removed: ${target.name}`;
        refreshVisibleCandidateCount();
        return { ok: true, name: target.name, mode: "direct-delayed" };
      }
      return recordAttemptFailure(target, `Unfollow option not found for ${target.name}`);
    }

    cleaner.lastAction = `Unfollowing ${target.name}…`;
    unfollowAction.scrollIntoView({ block: "center" });
    highlight(unfollowAction);
    if (!(await clickControl(unfollowAction))) {
      return recordAttemptFailure(target, `Could not click Unfollow for ${target.name}`);
    }
    await sleep(650);

    // Pages and some profile layouts require Update/Save/Confirm.
    const dialogs = Array.from(document.querySelectorAll("[role='dialog']")).filter((el) => isVisible(el, 80));
    const confirm = dialogs.length ? await waitForAction(isConfirmText, 2200, dialogs) : null;
    if (confirm) {
      await clickControl(confirm);
      await sleep(700);
    }

    processedKeys.add(target.key);
    failedAttempts.delete(target.key);
    cleaner.removed += 1;
    cleaner.currentName = null;
    cleaner.lastAction = `Removed: ${target.name}`;
    closeTransientUi();
    await sleep(450);
    refreshVisibleCandidateCount();
    return { ok: true, name: target.name, mode: "menu" };
  }

  async function beginVerificationSweep() {
    cleaner.sweep = 2;
    cleaner.emptyBottomPasses = 0;
    failedAttempts.clear();
    cleaner.lastAction = "Final check: returning to the top and scanning again…";
    window.scrollTo({ top: 0, behavior: "smooth" });
    await sleep(2600);
  }

  function finishCleaner() {
    for (const [key, attempts] of failedAttempts.entries()) {
      if (attempts >= 3 && !processedKeys.has(key)) finalSkippedKeys.add(key);
    }
    cleaner.skipped = finalSkippedKeys.size;
    cleaner.running = false;
    cleaner.paused = false;
    cleaner.stopRequested = false;
    cleaner.currentName = null;
    cleaner.finishedAt = new Date().toISOString();
    cleaner.visibleCandidates = 0;
    cleaner.lastAction = cleaner.skipped
      ? `Finished. Removed ${cleaner.removed}; ${cleaner.skipped} item(s) had no usable Unfollow action.`
      : `Finished. All detected following items were processed (${cleaner.removed} removed).`;
  }

  async function runCleanerLoop() {
    while (cleaner.running && !cleaner.stopRequested) {
      if (cleaner.paused) {
        await sleep(350);
        continue;
      }

      const result = await unfollowOne();

      if (result.ok) {
        cleaner.emptyBottomPasses = 0;
        if (!cleaner.running || cleaner.stopRequested) break;
        const wait = randomDelay();
        cleaner.lastAction = `${cleaner.lastAction} Next account in ${Math.ceil(wait / 1000)}s.`;
        await sleep(wait);
        continue;
      }

      if (result.code === "WRONG_PAGE") {
        cleaner.errors += 1;
        cleaner.lastAction = result.error;
        break;
      }

      if (result.code === "FACEBOOK_BLOCK") {
        cleaner.errors += 1;
        cleaner.lastAction = result.error;
        break;
      }

      if (result.code === "ACTION_NOT_FOUND") {
        // Do not stop. Try other visible cards, then continue scrolling.
        await sleep(900);
        if (findCandidateButtons().length > 0) continue;
      }

      cleaner.lastAction = "Loading the next following items…";
      const load = await loadMoreCandidates();
      if (findCandidateButtons().length > 0) {
        cleaner.emptyBottomPasses = 0;
        continue;
      }

      if (!load.atBottom) {
        cleaner.emptyBottomPasses = 0;
        await sleep(500);
        continue;
      }

      cleaner.emptyBottomPasses += 1;
      cleaner.lastAction = `Checking list end… ${cleaner.emptyBottomPasses}/3`;
      await sleep(1500);

      if (cleaner.emptyBottomPasses < 3) continue;
      if (cleaner.sweep === 1) {
        await beginVerificationSweep();
        continue;
      }

      finishCleaner();
      return;
    }

    if (!cleaner.stopRequested && cleaner.running) {
      cleaner.running = false;
      cleaner.paused = false;
      cleaner.currentName = null;
      cleaner.finishedAt = new Date().toISOString();
    }
  }

  function publicCleanerState() {
    refreshVisibleCandidateCount();
    return {
      ...cleaner,
      isFollowingPage: isFollowingPage(),
      url: location.href,
    };
  }

  async function startCleaner(options = {}) {
    if (cleaner.running) return publicCleanerState();
    cleaner.delayMin = Math.max(2500, Number(options.delayMin) || 5000);
    cleaner.delayMax = Math.max(cleaner.delayMin, Number(options.delayMax) || 8000);
    cleaner.running = true;
    cleaner.paused = false;
    cleaner.stopRequested = false;
    cleaner.startedAt = new Date().toISOString();
    cleaner.finishedAt = null;
    cleaner.lastAction = "Starting continuous one-by-one unfollow…";
    cleaner.sweep = 1;
    cleaner.emptyBottomPasses = 0;
    cleaner.removed = 0;
    cleaner.skipped = 0;
    cleaner.errors = 0;
    processedKeys.clear();
    failedAttempts.clear();
    finalSkippedKeys.clear();

    cleanerLoopPromise = runCleanerLoop().catch((err) => {
      cleaner.running = false;
      cleaner.paused = false;
      cleaner.currentName = null;
      cleaner.errors += 1;
      cleaner.finishedAt = new Date().toISOString();
      cleaner.lastAction = `Stopped by page error: ${String(err?.message || err)}`;
    });
    void cleanerLoopPromise;
    return publicCleanerState();
  }

  // Keep profile data fresh on Facebook SPA navigation.
  let debounceTimer = null;
  const observer = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      try {
        lastScrape = scrapeProfileData();
        refreshVisibleCandidateCount();
      } catch (err) {
        console.debug("[FB Following Cleaner] refresh failed:", err);
      }
    }, 800);
  });
  if (document.body) observer.observe(document.body, { childList: true, subtree: true });

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const type = message?.type;

    if (type === "GET_PROFILE_DATA") {
      try {
        lastScrape = scrapeProfileData();
        sendResponse({ ok: true, data: lastScrape });
      } catch (err) {
        sendResponse({ ok: false, error: String(err) });
      }
      return true;
    }

    if (type === "GET_UNFOLLOW_STATUS" || type === "UNFOLLOW_SCAN") {
      sendResponse({ ok: true, data: publicCleanerState() });
      return true;
    }

    if (type === "UNFOLLOW_ONE") {
      (async () => {
        try {
          const result = await unfollowOne();
          sendResponse({ ok: result.ok, result, data: publicCleanerState() });
        } catch (err) {
          cleaner.errors += 1;
          cleaner.lastAction = String(err?.message || err);
          sendResponse({ ok: false, error: cleaner.lastAction, data: publicCleanerState() });
        }
      })();
      return true;
    }

    if (type === "UNFOLLOW_START") {
      (async () => sendResponse({ ok: true, data: await startCleaner(message.options) }))();
      return true;
    }

    if (type === "UNFOLLOW_PAUSE") {
      cleaner.paused = true;
      cleaner.lastAction = "Paused.";
      sendResponse({ ok: true, data: publicCleanerState() });
      return true;
    }

    if (type === "UNFOLLOW_RESUME") {
      if (cleaner.running) {
        cleaner.paused = false;
        cleaner.lastAction = "Resumed continuous unfollow.";
      }
      sendResponse({ ok: true, data: publicCleanerState() });
      return true;
    }

    if (type === "UNFOLLOW_STOP") {
      cleaner.stopRequested = true;
      cleaner.running = false;
      cleaner.paused = false;
      cleaner.currentName = null;
      cleaner.finishedAt = new Date().toISOString();
      cleaner.lastAction = "Stopped by user.";
      sendResponse({ ok: true, data: publicCleanerState() });
      return true;
    }

    return false;
  });

  chrome.runtime.sendMessage(
    { type: "FACEBOOK_TAB_DETECTED", pageKind: lastScrape.pageKind },
    () => void chrome.runtime.lastError
  );
})();
