(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const statusPill = $("status-pill");
  const statusLabel = $("status-label");
  const stateNotFacebook = $("state-not-facebook");
  const stateNonProfile = $("state-non-profile");
  const stateProfile = $("state-profile");
  const unfollowManager = $("unfollow-manager");
  const toastEl = $("toast");

  const profilePhoto = $("profile-photo");
  const photoFallback = $("identity-photo-fallback");
  const profileName = $("profile-name");
  const profileUsername = $("profile-username");
  const profileBio = $("profile-bio");
  const statFollowers = $("stat-followers");
  const statFollowing = $("stat-following");
  const statFriends = $("stat-friends");
  const statsEmptyNote = $("stats-empty-note");
  const scrapedAtEl = $("scraped-at");

  const openFollowingBtn = $("open-following-btn");
  const visibleCount = $("visible-count");
  const removedCount = $("removed-count");
  const errorCount = $("error-count");
  const cleanerPageNote = $("cleaner-page-note");
  const cleanerLastAction = $("cleaner-last-action");
  const cleanerRunningDot = $("cleaner-running-dot");
  const delaySelect = $("delay-select");
  const removeNextBtn = $("remove-next-btn");
  const startAllBtn = $("start-all-btn");
  const pauseBtn = $("pause-btn");
  const stopBtn = $("stop-btn");

  let currentProfileData = null;
  let activeTabId = null;
  let isFacebookTab = false;
  let cleanerState = null;
  let pollTimer = null;

  function isFacebookUrl(urlString) {
    try {
      return /(^|\.)facebook\.com$/i.test(new URL(urlString).hostname);
    } catch {
      return false;
    }
  }

  function setStatus(kind, label) {
    statusPill.className = `status-pill status-pill--${kind}`;
    statusLabel.textContent = label;
  }

  function showProfileState(which) {
    stateNotFacebook.classList.toggle("hidden", which !== "not-facebook");
    stateNonProfile.classList.toggle("hidden", which !== "non-profile");
    stateProfile.classList.toggle("hidden", which !== "profile");
  }

  function showToast(message, duration = 2200) {
    toastEl.textContent = message;
    toastEl.classList.remove("hidden");
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toastEl.classList.add("hidden"), duration);
  }

  function setStat(el, stat) {
    el.textContent = stat?.display || "—";
    el.classList.toggle("is-empty", !stat?.display);
  }

  function formatTimestamp(iso) {
    if (!iso) return "—";
    try {
      return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    } catch {
      return "—";
    }
  }

  function renderProfile(data) {
    currentProfileData = data;
    if (data.photoUrl) {
      profilePhoto.src = data.photoUrl;
      profilePhoto.classList.remove("hidden");
      photoFallback.style.display = "none";
      profilePhoto.onerror = () => {
        profilePhoto.classList.add("hidden");
        photoFallback.style.display = "flex";
      };
    } else {
      profilePhoto.classList.add("hidden");
      photoFallback.style.display = "flex";
    }
    profileName.textContent = data.name || "Facebook profile";
    profileUsername.textContent = data.username ? `@${data.username}` : "—";
    profileBio.textContent = data.bio || "";
    profileBio.classList.toggle("hidden", !data.bio);
    setStat(statFollowers, data.stats?.followers);
    setStat(statFollowing, data.stats?.following);
    setStat(statFriends, data.stats?.friends);
    const anyStat = data.stats?.followers?.display || data.stats?.following?.display || data.stats?.friends?.display;
    statsEmptyNote.classList.toggle("hidden", Boolean(anyStat));
    scrapedAtEl.textContent = formatTimestamp(data.scrapedAt);
    showProfileState("profile");
  }

  function sendMessage(tabId, message) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, message, (response) => {
        if (chrome.runtime.lastError) return resolve(null);
        resolve(response || null);
      });
    });
  }

  async function ensureContentScript(tabId) {
    let response = await sendMessage(tabId, { type: "GET_UNFOLLOW_STATUS" });
    if (response) return true;
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
      await new Promise((resolve) => setTimeout(resolve, 180));
      response = await sendMessage(tabId, { type: "GET_UNFOLLOW_STATUS" });
      return Boolean(response);
    } catch (err) {
      console.debug("[FB Following Cleaner] injection failed:", err);
      return false;
    }
  }

  async function command(type, extra = {}) {
    if (activeTabId == null) return null;
    const response = await sendMessage(activeTabId, { type, ...extra });
    if (response?.data) renderCleaner(response.data);
    return response;
  }

  function renderCleaner(state) {
    cleanerState = state;
    visibleCount.textContent = String(state.visibleCandidates || 0);
    removedCount.textContent = String(state.removed || 0);
    errorCount.textContent = String((state.errors || 0) + (state.skipped || 0));
    cleanerLastAction.textContent = state.lastAction || "Ready.";
    cleanerPageNote.textContent = state.isFollowingPage
      ? "Following list detected. Keep this tab open."
      : "Open your Following list before starting.";
    cleanerPageNote.classList.toggle("page-note--ok", Boolean(state.isFollowingPage));
    cleanerRunningDot.classList.toggle("run-dot--active", Boolean(state.running && !state.paused));
    cleanerRunningDot.classList.toggle("run-dot--paused", Boolean(state.paused));

    const running = Boolean(state.running);
    const paused = Boolean(state.paused);
    startAllBtn.disabled = running || !state.isFollowingPage;
    removeNextBtn.disabled = running || !state.isFollowingPage;
    delaySelect.disabled = running;
    pauseBtn.disabled = !running;
    stopBtn.disabled = !running;
    pauseBtn.textContent = paused ? "Resume" : "Pause";
  }

  async function refreshCleanerStatus() {
    if (!isFacebookTab || activeTabId == null) return;
    const response = await command("GET_UNFOLLOW_STATUS");
    if (!response) cleanerLastAction.textContent = "Reload the Facebook tab once, then retry.";
  }

  async function loadForActiveTab() {
    setStatus("pending", "Checking…");
    showProfileState("not-facebook");
    unfollowManager.classList.add("hidden");

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url || tab.id == null) {
      setStatus("inactive", "No active tab");
      return;
    }

    activeTabId = tab.id;
    isFacebookTab = isFacebookUrl(tab.url);
    if (!isFacebookTab) {
      setStatus("inactive", "Not on Facebook");
      return;
    }

    setStatus("active", "Facebook detected");
    unfollowManager.classList.remove("hidden");
    const ready = await ensureContentScript(tab.id);
    if (!ready) {
      showProfileState("non-profile");
      cleanerLastAction.textContent = "Reload this Facebook tab once after installing the extension.";
      return;
    }

    const profileResponse = await sendMessage(tab.id, { type: "GET_PROFILE_DATA" });
    if (profileResponse?.ok && profileResponse.data?.pageKind === "profile") renderProfile(profileResponse.data);
    else showProfileState("non-profile");

    await refreshCleanerStatus();
    clearInterval(pollTimer);
    pollTimer = setInterval(refreshCleanerStatus, 800);
  }

  openFollowingBtn.addEventListener("click", async () => {
    if (activeTabId == null) return;
    // Facebook normally redirects /me/following to the signed-in account.
    await chrome.tabs.update(activeTabId, { url: "https://www.facebook.com/me/following" });
    window.close();
  });

  removeNextBtn.addEventListener("click", async () => {
    removeNextBtn.disabled = true;
    cleanerLastAction.textContent = "Removing next followed account…";
    const response = await command("UNFOLLOW_ONE");
    if (!response?.ok) showToast(response?.result?.error || response?.error || "Unfollow action not found.", 3000);
    else showToast(`Removed ${response.result?.name || "one account"} ✓`);
    removeNextBtn.disabled = Boolean(cleanerState?.running) || !cleanerState?.isFollowingPage;
  });

  startAllBtn.addEventListener("click", async () => {
    const confirmed = confirm("Start continuous one-by-one unfollow? It will auto-scroll and keep going until the final list check is complete or you press Stop.");
    if (!confirmed) return;
    const [delayMin, delayMax] = delaySelect.value.split(",").map(Number);
    await command("UNFOLLOW_START", { options: { delayMin, delayMax } });
    showToast("Continuous cleaner started ✓");
  });

  pauseBtn.addEventListener("click", async () => {
    await command(cleanerState?.paused ? "UNFOLLOW_RESUME" : "UNFOLLOW_PAUSE");
  });

  stopBtn.addEventListener("click", async () => {
    await command("UNFOLLOW_STOP");
    showToast("Cleaner stopped");
  });

  $("refresh-btn").addEventListener("click", loadForActiveTab);

  function triggerDownload(filename, mimeType, content) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  function safeSlug(text) {
    return (text || "profile").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 40) || "profile";
  }

  $("export-json").addEventListener("click", () => {
    if (!currentProfileData) return;
    triggerDownload(`fb-profile-${safeSlug(currentProfileData.username || currentProfileData.name)}.json`, "application/json", JSON.stringify(currentProfileData, null, 2));
  });

  $("export-csv").addEventListener("click", () => {
    if (!currentProfileData) return;
    const d = currentProfileData;
    const esc = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
    const rows = [["Field", "Value"], ["Name", d.name], ["Username", d.username], ["URL", d.url], ["Followers", d.stats?.followers?.display], ["Following", d.stats?.following?.display], ["Friends", d.stats?.friends?.display]];
    triggerDownload(`fb-profile-${safeSlug(d.username || d.name)}.csv`, "text/csv", rows.map((r) => r.map(esc).join(",")).join("\r\n"));
  });

  window.addEventListener("unload", () => clearInterval(pollTimer));
  loadForActiveTab().catch((err) => {
    console.error(err);
    setStatus("inactive", "Extension error");
  });
})();
